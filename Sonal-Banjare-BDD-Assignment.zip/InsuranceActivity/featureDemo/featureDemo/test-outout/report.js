$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("G:/PROJECTwildfly/featureDemo/featureDemo/src/main/java/feature/login.feature");
formatter.feature({
  "name": "Login Feature",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "InsuranceWeb: Home Login Test Scenario",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "user is available on Login Page",
  "keyword": "Given "
});
formatter.step({
  "name": "title of login page is InsuranceWeb: Home",
  "keyword": "When "
});
formatter.step({
  "name": "user enters \"\u003cusername\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "name": "user clicks on login button",
  "keyword": "Then "
});
formatter.step({
  "name": "user selects from option available",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ]
    },
    {
      "cells": [
        "kashi@gmail.com",
        "johna"
      ]
    }
  ]
});
formatter.scenario({
  "name": "InsuranceWeb: Home Login Test Scenario",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "user is available on Login Page",
  "keyword": "Given "
});
formatter.match({
  "location": "login.user_is_available_on_Login_Page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "title of login page is InsuranceWeb: Home",
  "keyword": "When "
});
formatter.match({
  "location": "login.title_of_login_page_is_InsuranceWeb_Home()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user enters \"kashi@gmail.com\" and \"johna\"",
  "keyword": "Then "
});
formatter.match({
  "location": "login.user_enters_and(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks on login button",
  "keyword": "Then "
});
formatter.match({
  "location": "login.user_clicks_on_login_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user selects from option available",
  "keyword": "Then "
});
formatter.match({
  "location": "login.user_selects_from_option_available()"
});
formatter.result({
  "status": "passed"
});
});