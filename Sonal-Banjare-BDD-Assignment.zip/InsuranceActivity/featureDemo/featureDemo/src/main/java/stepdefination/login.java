package stepdefination;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class login {
	WebDriver driver;
	@Given("^user is available on Login Page$")
	public void user_is_available_on_Login_Page() throws IOException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\soft\\Selenium\\chromeDriver.exe");

		driver=new ChromeDriver(); 
		  driver.get("https://demo.borland.com/InsuranceWebExtJS/index.jsf");
		  File src=	((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src,new File("C:\\Users\\HP\\Desktop\\screenshots\\Home.png"));
				 // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^title of login page is InsuranceWeb: Home$")
	public void title_of_login_page_is_InsuranceWeb_Home() {
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals("InsuranceWeb: Home",title);
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^user enters \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_and(String username, String password) {
		System.out.println(username);
		System.out.println(password);
		driver.findElement(By.id("login-form:email")).sendKeys(username);
		driver.findElement(By.id("login-form:password")).sendKeys(password);
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@Then("^user clicks on login button$")
	public void user_clicks_on_login_button() throws IOException {
		driver.findElement(By.name("login-form:login")).click();
	    // Write code here that turns the phrase above into concrete actions
		File src=	((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src,new File("C:\\Users\\HP\\Desktop\\screenshots\\invalid.png")); 
	}
	@Then("^user selects from option available$")
	public void user_selects_from_option_available() throws IOException
	{
		Select sel=new Select(driver.findElement(By.id("quick-link:jump-menu")));
		   sel.selectByIndex(2);
		   File src=	((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src,new File("C:\\Users\\HP\\Desktop\\screenshots\\invaliddropdown.png"));
	}



    
	
}
