package stepdefination;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class signUp {
	WebDriver driver;
	@Given("^user is already on Signup Page$")
	public void user_is_already_on_Signup_Page() {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\soft\\Selenium\\chromeDriver.exe");

		driver=new ChromeDriver(); 
		  driver.get("https://demo.borland.com/InsuranceWebExtJS/signup.jsf");
		
		
		
	}

	@Then("^user enters \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_and_and_and_and_and_and_and_and(String fname, String lname, String dob, String email, String street, String city, String state, String zip, String password) throws IOException {

		
		driver.findElement(By.id("signup:fname")).sendKeys(fname);
		driver.findElement(By.id("signup:lname")).sendKeys(lname);
		driver.findElement(By.id("BirthDate")).sendKeys(dob);
		driver.findElement(By.id("signup:email")).sendKeys(email);
		driver.findElement(By.id("signup:street")).sendKeys(street);
		driver.findElement(By.id("signup:city")).sendKeys(city);
		driver.findElement(By.id("signup:state")).sendKeys(state);
		driver.findElement(By.id("signup:zip")).sendKeys(zip);
		driver.findElement(By.id("signup:password")).sendKeys(password);
		
		File src=	((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src,new File("C:\\Users\\HP\\Desktop\\screenshots\\signup.png"));
		
		
		
	}

	@Then("^user clicks on sign up button$")
	public void user_clicks_on_sign_up_button() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//*[@id=\"signup:signup\"]")).click();
		File src=	((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src,new File("C:\\Users\\HP\\Desktop\\screenshots\\succesfull.png"));
	}
}
