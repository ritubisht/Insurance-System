package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="G:\\PROJECTwildfly\\featureDemo\\featureDemo\\src\\main\\java\\feature\\login.feature",
		glue="stepdefination",
		plugin= {"pretty","html:test-outout","json:json_output/cucumber.json","junit:junit_xml/cucumber.xml"},
		monochrome=true,strict= true, dryRun =false
		//tags= {"@SmokeTest,@RegressionTest"}//and means seperate coates awhile or means one coates for both
		
		
		)
public class test {

}
